const { buildSchema } = require('graphql');

module.exports = buildSchema(`

    type ERDDateRange {
        end:String!
        begin:String!
    }

    type ActualData {
        id:Int!
        loadPlanNumber:String!
        loadPlanName:String!
        status:String!
        origin:String!
        erdDateRange:ERDDateRange!
    }

    type LoadPlanData {
        results:[ActualData!]
    }

    type RootQuery {
        getLoadPlans:LoadPlanData!
    }

    type RootMutation {
        getParticularLoadPlan(id:Int!):LoadPlanData!
    }    
    schema {
        query:RootQuery
        mutation:RootMutation
    }

`);
