const express = require('express')
const graphQlHTTP = require('express-graphql')

const grapqlSchema = require('./graphQL/schema')
const grapqlResolver = require('./graphQL/resolvers')

const expressApp = express()

const PORT = process.env.local || 5001

//Middleware to parse JSON
expressApp.use(express.json({ extended: false }))

expressApp.use(
  '/graphql',
  graphQlHTTP({
    schema: grapqlSchema,
    rootValue: grapqlResolver,
    graphiql: true,
  })
)

expressApp.listen(PORT, () =>
  console.log(`Server Started with the port : ${PORT} succesfully`)
)
